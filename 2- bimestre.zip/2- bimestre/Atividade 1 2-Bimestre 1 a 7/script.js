let Resultado = document.querySelector("#Resultado");   
let Troco = document.querySelector("#Troco");
let Valorpago = document.querySelector("#Valorpago");
let btDiminuir = document.querySelector("#btDiminuir");
 
function SomarNumeros(){

    let num1 = Number(Troco.value);
    let num2 = Number(Valorpago.value);

    Resultado.textContent = (num1 - num2);
}

btDiminuir.onclick = function(){
    SomarNumeros();
}

let Resultado2 = document.querySelector("#Resultado2");
let ValorQuilo = document.querySelector("#ValorQuilo")
let QuantidadeQuilo = document.querySelector("#QuantidadeQuilo")
let BtKG = document.querySelector("#BtKG")

function MultiplicarNumeros(){

    let num1 = Number(ValorQuilo.value);
    let num2 = Number(QuantidadeQuilo.value);

    Resultado2.textContent = (num1 * num2);
}

BtKG.onclick = function(){
    MultiplicarNumeros();
}

let Saldo = document.querySelector("#Saldo");
let btCalcular = document.querySelector("#btCalcular");
let Resultado3 = document.querySelector("#Resultado3");

function PorcentagemNumeros(){

    let num1 = Number(Saldo.value);

    Resultado3.textContent = (num1*(1/100)) + num1;
}

btCalcular.onclick = function(){
    PorcentagemNumeros();
}

let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let numero3 = document.querySelector("#numero3");
let btMed = document.querySelector("#btMed");
let ResultadoAritimetica = document.querySelector("#ResultadoAritimetica");
let ResultadoPonderada = document.querySelector("#ResultadoPonderada");
let ResultadoDasMedias = document.querySelector("#ResultadoDasMedias");
let ResultadoMediaDasMedias = document.querySelector("#ResultadoMediaDasMedias");

function CalcularMedias(){
     
    let num1 = Number(numero1.value);
    let num2 = Number(numero2.value);
    let num3 = Number(numero3.value);

    let mediaAritimetica = (num1 + num2 + num3) / 3;
    
    let mediaPonderada = (num1 * 3 + num2 * 2 + num3 * 5) / (3 + 2 + 5);

    let SomaMedias = mediaAritimetica + mediaPonderada;
    
    let MediadasMedias = (mediaAritimetica + mediaPonderada) / 2;

    ResultadoAritimetica.textContent = mediaAritimetica;
    ResultadoPonderada.textContent =  mediaPonderada;
    ResultadoDasMedias.textContent = SomaMedias
    ResultadoMediaDasMedias.textContent = MediadasMedias;


}
btMed.onclick = function(){
    CalcularMedias();
}

let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let btValores = document.querySelector("#btValores")
let Resultado5 = document.querySelector("#Resultado5")

function CompararValores(){

    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);

    if (num1 > num2) {
        Resultado5.textContent = "Valor 1 e Maior =  " + num1;
    } 
    else {
        Resultado5.textContent = "Valor 2 e Maior =  " + num2; 
    }

    }
    btValores.onclick = function(){
        CompararValores()
    }


    let ValoR1 = document.querySelector("#ValoR1");
    let ValoR2 = document.querySelector("#ValoR2");
    let ValoR3 = document.querySelector("#ValoR3");
    let ValoR4 = document.querySelector("#ValoR4");
    let ValoresBT = document.querySelector("#ValoresBT");
    let Resultado6 = document.querySelector("#Resultado6");

    function CompararValoresMenor(){

        let num1 = Number(ValoR1.value);
        let num2 = Number(ValoR2.value);
        let num3 = Number(ValoR3.value);
        let num4 = Number(ValoR4.value);

        if (num1 < num2 && num1 < num3 && num1 < num4) {
            Resultado6.textContent = "Valor 1 e Menor = " + num1;
        }
        else if (num2 < num1 && num2 < num3 && num2 < num4) {
            Resultado6.textContent = "Valor 2 e Menor =" + num2;
        }
        else if (num3 < num1 && num3 < num2 && num3 < num4)
            Resultado6.textContent = "Valor 3 e Menor =" + num3;
        else {
            Resultado6.textContent = "Valor 4 e Menor" + num4;
        } 
    }
    ValoresBT.onclick = function(){
        CompararValoresMenor()
    }


    let Valor11 = document.querySelector("#Valor11");
    let VALORBT = document.querySelector("#VALORBT");
    let Resultado7 = document.querySelector("#Resultado7")

    function ValorImpar(){

        let num1 = Number(Valor11.value);

        if (num1 % 2 == 0){
            Resultado7.textContent = "O numero e Par!"
        }
        else if (num1 % 2 == 1) {
            Resultado7.textContent = "O Numero e Impar !"
        }
        else {
            Resultado.textContent = "Numero Invalido !"
        }
    }
    VALORBT.onclick = function(){
        ValorImpar()
    }
