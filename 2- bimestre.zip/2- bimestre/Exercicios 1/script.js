let Resultado = document.querySelector("#Resultado");   
let Troco = document.querySelector("#Troco");
let Valorpago = document.querySelector("#Valorpago");
let btDiminuir = document.querySelector("#btDiminuir");
 
function SomarNumeros(){

    let num1 = Number(Troco.value);
    let num2 = Number(Valorpago.value);

    Resultado.textContent = (num1 - num2);
}

btDiminuir.onclick = function(){
    SomarNumeros();
}

let Resultado2 = document.querySelector("#Resultado2");
let ValorQuilo = document.querySelector("#ValorQuilo")
let QuantidadeQuilo = document.querySelector("#QuantidadeQuilo")
let BtKG = document.querySelector("#BtKG")

function MultiplicarNumeros(){

    let num1 = Number(ValorQuilo.value);
    let num2 = Number(QuantidadeQuilo.value);

    Resultado2.textContent = (num1 * num2);
}

BtKG.onclick = function(){
    MultiplicarNumeros();
}

let Saldo = document.querySelector("#Saldo");
let btCalcular = document.querySelector("#btCalcular");
let Resultado3 = document.querySelector("#Resultado3");

function PorcentagemNumeros(){

    let num1 = Number(Saldo.value);

    Resultado3.texContent = ((num1 *(1/100)) + num1);
}

btCalcular.onclick = function(){
    PorcentagemNumeros();
}