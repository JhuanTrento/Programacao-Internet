let Resultado = document.querySelector("#Resultado");   
let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let btSomar = document.querySelector("#btSomar");
 
function SomarNumeros(){

    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);

    Resultado.textContent = (num1 + num2);
}

btSomar.onclick = function(){
    SomarNumeros();
}

let Resultado2 = document.querySelector("#Resultado2");   
let Troco = document.querySelector("#Troco");
let Valorpago = document.querySelector("#Valorpago");
let btDiminuir = document.querySelector("#btDiminuir");
 
function SomarNumeros2(){

    let num1 = Number(Troco.value);
    let num2 = Number(Valorpago.value);

    Resultado2.textContent = (num1 - num2);
}

btDiminuir.onclick = function(){
    SomarNumeros2();
}