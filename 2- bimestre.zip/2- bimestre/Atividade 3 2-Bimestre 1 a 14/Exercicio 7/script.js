let dia = document.querySelector("#dia");
let mes = document.querySelector("#mes");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularDias() {
    let d = Number(dia.value);
    let m = Number(mes.value);

    if (d < 1 || d > 30 || m < 1 || m > 12 || isNaN(d) || isNaN(m)) {
        resultado.textContent = "Informe valores válidos para dia (1-30) e mês (1-12).";
        return;
    }

    let totalDias = (m - 1) * 30 + d;

    resultado.textContent = "Dias desde o inicio do ano: " + totalDias;
}

btCalcular.onclick = function () {
    calcularDias();
};