let PrecoLitro = document.querySelector("#PrecoLitro");
let ValorPago = document.querySelector("#ValorPago");
let BtCalcular = document.querySelector("#BtCalcular");
let Resultado = document.querySelector("#Resultado");

function CalcularLitros() {
    let preco = Number(PrecoLitro.value);
    let valor = Number(ValorPago.value);

    if (preco <= 0 || valor < 0 || isNaN(preco) || isNaN(valor)) {
        Resultado.textContent = "Por favor, insira valores válidos.";
        return;
    }

    let litros = valor / preco;

    Resultado.textContent = "Com R$ " + valor.toFixed(2) + 
        " você conseguiu colocar " + litros.toFixed(2) + " litros no tanque.";
}

BtCalcular.onclick = function () {
    CalcularLitros();
}