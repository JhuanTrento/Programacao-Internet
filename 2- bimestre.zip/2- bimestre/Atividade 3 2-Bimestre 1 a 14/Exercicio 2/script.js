let Cavalos = document.querySelector("#Cavalos")
let BtCalcular = document.querySelector("#BtCalcular")
let Resultado = document.querySelector("#Resultado")

function CalcularFerraduras(){

    let num1 = Number(Cavalos.value);

    Resultado.textContent = "Serao necessarias  " + (num1 * 4) +"  ferraduras para  "+ num1 +" cavalos."
}

BtCalcular.onclick = function(){
    CalcularFerraduras()
}