let PesoPrato = document.querySelector("#PesoPrato");
let BtCalcular = document.querySelector("#BtCalcular");
let Resultado = document.querySelector("#Resultado");

function CalcularValor() {
    let peso = Number(PesoPrato.value);
    const precoPorKg = 12.00;

    if (peso <= 0 || isNaN(peso)) {
        Resultado.textContent = "Informe um peso válido.";
        return;
    }

    let total = peso * precoPorKg;

    Resultado.textContent = "Valor a pagar: R$ " + total.toFixed(2);
}

BtCalcular.onclick = function () {
    CalcularValor();
}