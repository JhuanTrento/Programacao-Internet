let x1 = document.querySelector("#x1");
let y1 = document.querySelector("#y1");
let x2 = document.querySelector("#x2");
let y2 = document.querySelector("#y2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularDistancia() {
    let a = Number(x1.value);
    let b = Number(y1.value);
    let c = Number(x2.value);
    let d = Number(y2.value);

    if (isNaN(a) || isNaN(b) || isNaN(c) || isNaN(d)) {
        resultado.textContent = "Por favor, insira valores numéricos válidos.";
        return;
    }

    let distancia = Math.sqrt((c - a) ** 2 + (d - b) ** 2);
    resultado.textContent = "Distância: " + distancia.toFixed(2);
}

btCalcular.onclick = function () {
    calcularDistancia();
};