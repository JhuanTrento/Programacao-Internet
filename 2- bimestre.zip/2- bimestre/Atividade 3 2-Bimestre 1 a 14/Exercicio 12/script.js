let numero = document.querySelector("#numero");
let btSeparar = document.querySelector("#btSeparar");
let resultado = document.querySelector("#resultado");

function separarDigitos() {
    let n = Number(numero.value);

    if (isNaN(n) || n < 0 || n > 999 || !Number.isInteger(n)) {
        resultado.textContent = "Digite um numero inteiro entre 0 e 999.";
        return;
    }

    let centena = Math.floor(n / 100);
    let dezena = Math.floor((n % 100) / 10);
    let unidade = n % 10;

    resultado.textContent =
        "CENTENA = " + centena + "\n" +
        "DEZENA = " + dezena + "\n" +
        "UNIDADE = " + unidade;
}

btSeparar.onclick = function () {
    separarDigitos();
};