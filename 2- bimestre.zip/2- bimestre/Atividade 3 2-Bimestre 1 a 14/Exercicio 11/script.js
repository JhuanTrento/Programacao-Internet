let salarioInicial = document.querySelector("#salarioInicial");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularSalario() {
    let salario = Number(salarioInicial.value);

    if (isNaN(salario) || salario <= 0) {
        resultado.textContent = "Por favor, digite um salario valido.";
        return;
    }

    let comAumento = salario * 1.15;
    let salarioFinal = comAumento * 0.92;

    resultado.textContent =
        "Salario inicial: R$ " + salario.toFixed(2) +
        " | Com aumento: R$ " + comAumento.toFixed(2) +
        " | Salario final: R$ " + salarioFinal.toFixed(2);
}

btCalcular.onclick = function () {
    calcularSalario();
};