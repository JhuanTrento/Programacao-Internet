let pequenas = document.querySelector("#qtdPequenas");
let medias = document.querySelector("#qtdMedias");
let grandes = document.querySelector("#qtdGrandes");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularTotal() {
    let p = Number(pequenas.value);
    let m = Number(medias.value);
    let g = Number(grandes.value);

    if (isNaN(p) || isNaN(m) || isNaN(g) || p < 0 || m < 0 || g < 0) {
        resultado.textContent = "Por favor, insira quantidades válidas.";
        return;
    }

    let total = (p * 10) + (m * 12) + (g * 15);
    resultado.textContent = "Valor total arrecadado: R$ " + total.toFixed(2);
}

btCalcular.onclick = function () {
    calcularTotal();
};