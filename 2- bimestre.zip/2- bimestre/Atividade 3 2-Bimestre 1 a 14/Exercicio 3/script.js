let Paes = document.querySelector("#Paes");
let Broas = document.querySelector("#Broas");
let BtCalcular = document.querySelector("#BtCalcular");
let Resultado = document.querySelector("#Resultado");

function CalcularVenda() {
    let qtdPaes = Number(Paes.value);
    let qtdBroas = Number(Broas.value);

    let total = (qtdPaes * 0.12) + (qtdBroas * 1.50);
    let poupanca = total * 0.10;

    Resultado.textContent = "Total arrecadado: R$ " + total.toFixed(2) +
        " | Valor para poupança (10%): R$ " + poupanca.toFixed(2);
}

BtCalcular.onclick = function () {
    CalcularVenda();
}