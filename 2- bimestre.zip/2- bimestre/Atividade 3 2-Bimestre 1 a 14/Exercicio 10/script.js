let inputDias = document.querySelector("#inputDias");
let btConverter = document.querySelector("#btConverter");
let resultado = document.querySelector("#resultado");

function converterTempo() {
    let totalDias = Number(inputDias.value);

    if (isNaN(totalDias) || totalDias < 0) {
        resultado.textContent = "Digite um número válido de dias.";
        return;
    }

    let anos = Math.floor(totalDias / 360);
    let resto = totalDias % 360;
    let meses = Math.floor(resto / 30);
    let dias = resto % 30;

    resultado.textContent = "Resultado: " + anos + " ano(s), " + meses + " mês(es), " + dias + " dia(s)";
}

btConverter.onclick = function () {
    converterTempo();
};