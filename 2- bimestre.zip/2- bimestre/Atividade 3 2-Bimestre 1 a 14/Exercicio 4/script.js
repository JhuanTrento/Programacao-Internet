let Nome = document.querySelector("#Nome");
let Idade = document.querySelector("#Idade");
let BtCalcular = document.querySelector("#BtCalcular");
let Resultado = document.querySelector("#Resultado");

function CalcularDiasDeVida() {
    let nome = Nome.value.toUpperCase();
    let idade = Number(Idade.value);

    if (!nome || isNaN(idade) || idade < 0) {
        Resultado.textContent = "Por favor, digite um nome e uma idade válidos.";
        return;
    }

    let dias = idade * 365;

    Resultado.textContent = nome + ", VOCÊ JÁ VIVEU " + dias + " DIAS";
}

BtCalcular.onclick = function () {
    CalcularDiasDeVida();
}