let raio = document.querySelector("#raio");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularArea() {
    let r = Number(raio.value);

    if (isNaN(r) || r <= 0) {
        resultado.textContent = "Digite um valor valido para o raio.";
        return;
    }

    let pi = 3.14;
    let area = pi * r * r;

    resultado.textContent = "Area da pizza = " + area.toFixed(2) + " cm²";
}

btCalcular.onclick = function () {
    calcularArea();
};