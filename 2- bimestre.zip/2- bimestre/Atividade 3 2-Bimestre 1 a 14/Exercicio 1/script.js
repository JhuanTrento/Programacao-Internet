let Largura = document.querySelector("#Largura");
let Comprimento = document.querySelector("#Comprimento");
let BtCalcular = document.querySelector("#BtCalcular");
let Resultado = document.querySelector("#Resultado");

function CalcularMetro(){

    let num1 = Number(Largura.value);
    let num2 = Number(Comprimento.value);

    Resultado.textContent = (num1 * num2) + "m² e a Area do terreno !";
}

BtCalcular.onclick = function(){
    CalcularMetro()
}