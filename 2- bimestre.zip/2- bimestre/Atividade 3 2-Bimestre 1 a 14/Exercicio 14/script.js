let conta = document.querySelector("#conta");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularDivisao() {
    let total = Number(conta.value);

    if (isNaN(total) || total <= 0) {
        resultado.textContent = "Digite um valor valido para a conta.";
        return;
    }

    let parteInteira = Math.floor(total / 3);
    let carlos = parteInteira;
    let andre = parteInteira;

    let parcial = carlos + andre;
    let felipe = total - parcial;

    resultado.textContent = 
        "Carlos paga: R$" + carlos.toFixed(2) + "\n" +
        "Andre paga: R$" + andre.toFixed(2) + "\n" +
        "Felipe paga: R$" + felipe.toFixed(2);
}

btCalcular.onclick = function () {
    calcularDivisao();
};