let Resultado = document.querySelector("#Resultado");   
let Troco = document.querySelector("#Troco");
let Valorpago = document.querySelector("#Valorpago");
let btDiminuir = document.querySelector("#btDiminuir");
 
function SomarNumeros(){

    let num1 = Number(Troco.value);
    let num2 = Number(Valorpago.value);

    Resultado.textContent = (num1 - num2);
}

btDiminuir.onclick = function(){
    SomarNumeros();
}

let Resultado2 = document.querySelector("#Resultado2");
let ValorQuilo = document.querySelector("#ValorQuilo")
let QuantidadeQuilo = document.querySelector("#QuantidadeQuilo")
let BtKG = document.querySelector("#BtKG")

function MultiplicarNumeros(){

    let num1 = Number(ValorQuilo.value);
    let num2 = Number(QuantidadeQuilo.value);

    Resultado2.textContent = (num1 * num2);
}

BtKG.onclick = function(){
    MultiplicarNumeros();
}

let Saldo = document.querySelector("#Saldo");
let btCalcular = document.querySelector("#btCalcular");
let Resultado3 = document.querySelector("#Resultado3");

function PorcentagemNumeros(){

    let num1 = Number(Saldo.value);

    Resultado3.textContent = (num1*(1/100)) + num1;
}

btCalcular.onclick = function(){
    PorcentagemNumeros();
}

let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let numero3 = document.querySelector("#numero3");
let btMed = document.querySelector("#btMed");
let ResultadoAritimetica = document.querySelector("#ResultadoAritimetica");
let ResultadoPonderada = document.querySelector("#ResultadoPonderada");
let ResultadoDasMedias = document.querySelector("#ResultadoDasMedias");
let ResultadoMediaDasMedias = document.querySelector("#ResultadoMediaDasMedias");

function CalcularMedias(){
     
    let num1 = Number(numero1.value);
    let num2 = Number(numero2.value);
    let num3 = Number(numero3.value);

    let mediaAritimetica = (num1 + num2 + num3) / 3;
    
    let mediaPonderada = (num1 * 3 + num2 * 2 + num3 * 5) / (3 + 2 + 5);

    let SomaMedias = mediaAritimetica + mediaPonderada;
    
    let MediadasMedias = (mediaAritimetica + mediaPonderada) / 2;

    ResultadoAritimetica.textContent = mediaAritimetica;
    ResultadoPonderada.textContent =  mediaPonderada;
    ResultadoDasMedias.textContent = SomaMedias
    ResultadoMediaDasMedias.textContent = MediadasMedias;


}
btMed.onclick = function(){
    CalcularMedias();
}

let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let btValores = document.querySelector("#btValores")
let Resultado5 = document.querySelector("#Resultado5")

function CompararValores(){

    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);

    if (num1 > num2) {
        Resultado5.textContent = "Valor 1 e Maior !";
    } else if (num2 > num1){
        Resultado5.textContent = "Valor 2 e Maior";  
    } else {
        Resultado5.textContent = "Os Dois Valores sao iguais." 
    }

    }
    btValores.onclick = function(){
        CompararValores()
    }
