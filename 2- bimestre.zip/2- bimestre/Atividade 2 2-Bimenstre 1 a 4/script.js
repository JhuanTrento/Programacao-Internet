

let ValorDollar = document.querySelector("#ValorDollar");
let BTCalcular = document.querySelector("#BTCalcular");
let Resultado1 = document.querySelector("#Resultado1");
let Resultado2 = document.querySelector("#Resultado2");
let Resultado5 = document.querySelector("#Resultado5");
let Resultado10 = document.querySelector("#Resultado10");

function PorcentagemDollar(){

    let num1 = Number(ValorDollar.value);
    
    Resultado1.textContent = (num1*(1/100)) + num1;
    Resultado2.textContent = (num1*(2/100)) + num1;
    Resultado5.textContent = (num1*(5/100)) + num1;
    Resultado10.textContent = (num1*(10/100)) + num1;
}
BTCalcular.onclick = function(){
    PorcentagemDollar()
}
