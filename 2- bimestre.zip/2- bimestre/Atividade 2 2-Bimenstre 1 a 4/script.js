

let ValorDollar = document.querySelector("#ValorDollar");
let BTCalcular = document.querySelector("#BTCalcular");
let Resultado1 = document.querySelector("#Resultado1");
let Resultado2 = document.querySelector("#Resultado2");
let Resultado5 = document.querySelector("#Resultado5");
let Resultado10 = document.querySelector("#Resultado10");

function PorcentagemDollar(){

    let num1 = Number(ValorDollar.value);
    
    Resultado1.textContent = (num1*(1/100)) + num1;
    Resultado2.textContent = (num1*(2/100)) + num1;
    Resultado5.textContent = (num1*(5/100)) + num1;
    Resultado10.textContent = (num1*(10/100)) + num1;
}
BTCalcular.onclick = function(){
    PorcentagemDollar()
}

let QuantidadePessoas = document.querySelector("#QuantidadePessoas");
let CalcularOmeleteBT = document.querySelector("#CalcularOmeleteBT");
let Resultado2Ovos = document.querySelector("#Resultado2Ovos");
let Resultado2Queijo = document.querySelector("#Resultado2Queijo")

function CalcularOmelete(){

    let num1 = Number(QuantidadePessoas.value);

    Resultado2Ovos.textContent = (num1 * 2) + "    Ovos" ;
    Resultado2Queijo.textContent = (num1 *50) + "    Gramas";
}

CalcularOmeleteBT.onclick = function(){
    CalcularOmelete()
}

let Valor1 = document.querySelector("#Valor1"); 
let Valor2 = document.querySelector("#Valor2");
let CalcularMatematicaBT = document.querySelector("#CalcularMatematicaBT");
let ResultadoSoma = document.querySelector("#ResultadoSoma"); 
let ResultadoSubtracao = document.querySelector("#ResultadoSubtracao"); 
let ResultadoMultiplicacao = document.querySelector("#ResultadoMultiplicacao"); 
let ResultadoDivisao = document.querySelector("#ResultadoDivisao"); 

function CalcularMatematica(){

    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);

    ResultadoSoma.textContent = (num1 + num2);
    ResultadoSubtracao.textContent = (num1 - num2);
    ResultadoMultiplicacao.textContent = (num1 * num2);
    ResultadoDivisao.textContent = (num1 % num2);

}
CalcularMatematicaBT.onclick = function(){
    CalcularMatematica()
}